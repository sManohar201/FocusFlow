# Overview

This is a cross-platform, web-based Deep Work Tracker application built to help users manage and track their focused work sessions. The application features a Pomodoro-style timer with customizable session lengths, productivity tracking through GitHub-style heatmaps, distraction logging, task management via a Kanban board, and comprehensive statistics. The system is deployed on Replit with a secure email/password authentication system backed by PostgreSQL database.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The application uses React with TypeScript as the primary frontend framework, styled with Tailwind CSS and shadcn/ui components. The frontend follows a modern component-based architecture with:

- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Animation**: Framer Motion for smooth transitions and animations
- **UI Components**: Comprehensive shadcn/ui component library with Radix UI primitives
- **Theme System**: Custom dark/light mode theme provider with CSS variables
- **Build System**: Vite for fast development and optimized production builds

## Backend Architecture
The backend is built with Node.js and Express, implementing a RESTful API architecture:

- **Database Layer**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Authentication**: Session-based email/password authentication with bcrypt password hashing
- **Data Storage**: PostgreSQL database with structured schema for users, sessions, tasks, and distractions
- **API Design**: RESTful endpoints for authentication, sessions, tasks, users, distractions, and analytics

## Database Schema Design
The application uses a relational database schema with four main entities:

- **Users**: Stores user credentials (email, password hash), profile information (first/last name), and settings
- **Sessions**: Tracks work/break sessions with duration, completion status, and associated tasks
- **Tasks**: Manages task lifecycle with status tracking, priority levels, and session estimation
- **Distractions**: Logs interruptions during sessions for productivity analysis

## Timer System
The core timer functionality implements multiple session modes:

- **Preset Modes**: 30-minute and 50-minute session options
- **Custom Duration**: User-configurable session lengths
- **Session Types**: Work sessions and break periods
- **Audio Feedback**: Web Audio API integration for session completion notifications
- **Progress Tracking**: Real-time session progress with visual indicators

## Analytics and Visualization
The productivity tracking system includes:

- **Heatmap Visualization**: GitHub-style contribution graph showing daily session counts
- **Statistical Analysis**: Daily, weekly, monthly, and all-time productivity metrics
- **Session Analytics**: Completion rates, total hours worked, and distraction tracking
- **Data Aggregation**: Flexible date range queries for performance analysis

# External Dependencies

## Frontend Dependencies
- **React Ecosystem**: React 18, React DOM, React Query for state management
- **UI Framework**: Tailwind CSS with shadcn/ui component library and Radix UI primitives
- **Animation**: Framer Motion for smooth transitions and micro-interactions
- **Routing**: Wouter for lightweight client-side navigation
- **Date Handling**: date-fns for date manipulation and formatting
- **Form Management**: React Hook Form with Zod validation

## Backend Dependencies
- **Runtime**: Node.js with Express.js web framework
- **Database**: Drizzle ORM with PostgreSQL support via @neondatabase/serverless
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions
- **Validation**: Zod for runtime type checking and schema validation
- **Build Tools**: esbuild for production bundling, tsx for development

## Development Tools
- **TypeScript**: Full type safety across frontend and backend
- **Vite**: Development server and build tool with React plugin
- **ESLint/Prettier**: Code formatting and linting
- **PostCSS**: CSS processing with Tailwind CSS

## Database Service
- **Neon Database**: Serverless PostgreSQL hosting for production deployment
- **Local Development**: In-memory storage fallback for development environments
- **Migration System**: Drizzle Kit for database schema management and migrations

The application is architected for easy deployment on Replit's free tier while maintaining scalability for future enhancements and user growth.