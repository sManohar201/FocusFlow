import { useState } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Clock, Bell, Database, Info } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import type { TimerSettings } from "@shared/schema";

export default function SettingsPanel() {
  const [settings, setSettings] = useState<TimerSettings>({
    sessionDuration: 50,
    shortBreak: 10,
    longBreak: 30,
    sessionsPerCycle: 4,
    soundEnabled: true,
    browserNotifications: false,
    theme: 'light',
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { logout } = useAuth();

  const updateSettingsMutation = useMutation({
    mutationFn: (newSettings: Partial<TimerSettings>) =>
      apiRequest('PATCH', '/api/settings', newSettings),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      toast({ title: "Success", description: "Settings updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update settings", variant: "destructive" });
    },
  });

  const handleSettingChange = (key: keyof TimerSettings, value: any) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    updateSettingsMutation.mutate({ [key]: value });
  };

  const handleExportData = async () => {
    try {
      const response = await fetch('/api/sessions');
      const sessions = await response.json();
      const dataStr = JSON.stringify(sessions, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `deep-work-data-${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
      toast({ title: "Success", description: "Data exported successfully" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to export data", variant: "destructive" });
    }
  };

  const handleClearData = () => {
    if (confirm("Are you sure you want to clear all data? This action cannot be undone.")) {
      // Implementation would clear all user data
      toast({ title: "Success", description: "All data cleared successfully" });
    }
  };

  const handleChangePasscode = () => {
    const newPasscode = prompt("Enter new passcode:");
    if (newPasscode) {
      // Implementation would update user passcode
      toast({ title: "Success", description: "Passcode updated successfully" });
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Settings</h2>
        <p className="text-slate-600 dark:text-slate-400 mt-1">
          Customize your deep work experience
        </p>
      </div>

      {/* Timer Settings */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-blue-500" />
              <span>Timer Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="session-duration">Session Duration (minutes)</Label>
                <Input
                  id="session-duration"
                  type="number"
                  min="1"
                  max="120"
                  value={settings.sessionDuration}
                  onChange={(e) => handleSettingChange('sessionDuration', parseInt(e.target.value) || 50)}
                  data-testid="input-session-duration"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="short-break">Short Break (minutes)</Label>
                <Input
                  id="short-break"
                  type="number"
                  min="1"
                  max="30"
                  value={settings.shortBreak}
                  onChange={(e) => handleSettingChange('shortBreak', parseInt(e.target.value) || 10)}
                  data-testid="input-short-break"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="long-break">Long Break (minutes)</Label>
                <Input
                  id="long-break"
                  type="number"
                  min="1"
                  max="60"
                  value={settings.longBreak}
                  onChange={(e) => handleSettingChange('longBreak', parseInt(e.target.value) || 30)}
                  data-testid="input-long-break"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sessions-per-cycle">Sessions per cycle</Label>
                <Select 
                  value={settings.sessionsPerCycle.toString()} 
                  onValueChange={(value) => handleSettingChange('sessionsPerCycle', parseInt(value))}
                >
                  <SelectTrigger data-testid="select-sessions-per-cycle">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2">2 sessions</SelectItem>
                    <SelectItem value="3">3 sessions</SelectItem>
                    <SelectItem value="4">4 sessions</SelectItem>
                    <SelectItem value="6">6 sessions</SelectItem>
                    <SelectItem value="8">8 sessions</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Notifications */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="w-5 h-5 text-yellow-500" />
              <span>Notifications</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="font-medium text-slate-900 dark:text-white">Sound notifications</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">
                  Play sound when sessions start/end
                </div>
              </div>
              <Switch
                checked={settings.soundEnabled}
                onCheckedChange={(checked) => handleSettingChange('soundEnabled', checked)}
                data-testid="switch-sound-enabled"
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="font-medium text-slate-900 dark:text-white">Browser notifications</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">
                  Send desktop notifications
                </div>
              </div>
              <Switch
                checked={settings.browserNotifications}
                onCheckedChange={(checked) => handleSettingChange('browserNotifications', checked)}
                data-testid="switch-browser-notifications"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Data Management */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="w-5 h-5 text-green-500" />
              <span>Data Management</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
              <div className="space-y-1">
                <div className="font-medium text-slate-900 dark:text-white">Change Passcode</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">
                  Update your access passcode
                </div>
              </div>
              <Button 
                onClick={handleChangePasscode}
                data-testid="button-change-passcode"
              >
                Change Passcode
              </Button>
            </div>
            <Separator />
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
              <div className="space-y-1">
                <div className="font-medium text-slate-900 dark:text-white">Export Data</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">
                  Download your session history
                </div>
              </div>
              <Button 
                variant="secondary" 
                onClick={handleExportData}
                data-testid="button-export-data"
              >
                Export JSON
              </Button>
            </div>
            <Separator />
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
              <div className="space-y-1">
                <div className="font-medium text-red-600 dark:text-red-400">Clear All Data</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">
                  Permanently delete all sessions and tasks
                </div>
              </div>
              <Button 
                variant="destructive" 
                onClick={handleClearData}
                data-testid="button-clear-data"
              >
                Clear Data
              </Button>
            </div>
            <Separator />
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
              <div className="space-y-1">
                <div className="font-medium text-slate-900 dark:text-white">Logout</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">
                  Sign out of your account
                </div>
              </div>
              <Button 
                variant="outline" 
                onClick={logout}
                data-testid="button-logout"
              >
                Logout
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* About */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Info className="w-5 h-5 text-blue-500" />
              <span>About</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between text-sm">
              <span className="text-slate-600 dark:text-slate-400">Version</span>
              <span className="font-medium">1.0.0</span>
            </div>
            <Separator />
            <div className="flex justify-between text-sm">
              <span className="text-slate-600 dark:text-slate-400">Last Updated</span>
              <span className="font-medium">August 2025</span>
            </div>
            <Separator />
            <div className="flex justify-between text-sm">
              <span className="text-slate-600 dark:text-slate-400">Storage Used</span>
              <span className="font-medium">2.3 KB</span>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
