import { useState } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

type TimePeriod = 'week' | 'month' | 'quarter' | 'all';

export default function StatsDigidboard() {
  const [selectedPeriod, setSelectedPeriod] = useState<TimePeriod>('week');

  const getDateRange = (period: TimePeriod) => {
    const now = new Date();
    const startDate = new Date();
    
    switch (period) {
      case 'week':
        startDate.setDate(now.getDate() - 7);
        break;
      case 'month':
        startDate.setMonth(now.getMonth() - 1);
        break;
      case 'quarter':
        startDate.setMonth(now.getMonth() - 3);
        break;
      case 'all':
        return {};
    }
    
    return { 
      startDate: startDate.toISOString(), 
      endDate: now.toISOString() 
    };
  };

  const dateRange = getDateRange(selectedPeriod);
  const queryParams = new URLSearchParams();
  if (dateRange.startDate) queryParams.set('startDate', dateRange.startDate);
  if (dateRange.endDate) queryParams.set('endDate', dateRange.endDate);
  
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/stats?' + queryParams.toString()],
  });

  const { data: sessions } = useQuery({
    queryKey: ['/api/sessions?' + queryParams.toString()],
  });

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded w-1/3"></div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-64 bg-slate-200 dark:bg-slate-700 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  const weeklyData = sessions?.reduce((acc: any, session: any) => {
    const day = new Date(session.startTime).toLocaleDateString('en-US', { weekday: 'short' });
    acc[day] = (acc[day] || 0) + (session.completed ? 1 : 0);
    return acc;
  }, {}) || {};

  const completionRates = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => {
    const completed = weeklyData[day] || 0;
    const total = sessions?.filter((s: any) => 
      new Date(s.startTime).toLocaleDateString('en-US', { weekday: 'short' }) === day
    ).length || 0;
    return { day, rate: total > 0 ? (completed / total) * 100 : 0 };
  });

  const bestHours = [
    { time: '9:00 AM - 11:00 AM', rate: 92 },
    { time: '2:00 PM - 4:00 PM', rate: 87 },
    { time: '7:00 PM - 9:00 PM', rate: 78 },
  ];

  const topDistractions = [
    { name: 'Social Media', count: 12 },
    { name: 'Notifications', count: 8 },
    { name: 'Email', count: 5 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
            Detailed Statistics
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Comprehensive analysis of your productivity patterns
          </p>
        </div>
      </div>

      {/* Time Period Selector */}
      <div className="flex flex-wrap gap-2">
        {[
          { key: 'week', label: 'Last 7 Days' },
          { key: 'month', label: 'Last 30 Days' },
          { key: 'quarter', label: 'Last 3 Months' },
          { key: 'all', label: 'All Time' },
        ].map(({ key, label }) => (
          <Button
            key={key}
            onClick={() => setSelectedPeriod(key as TimePeriod)}
            variant={selectedPeriod === key ? 'default' : 'secondary'}
            size="sm"
            data-testid={`button-period-${key}`}
          >
            {label}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Session Completion Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-slate-50 dark:bg-slate-900 p-6 rounded-xl"
        >
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">
            Session Completion Rate
          </h3>
          <div className="h-64 flex items-end justify-between space-x-2">
            {completionRates.map(({ day, rate }) => (
              <div key={day} className="flex flex-col items-center space-y-2 flex-1">
                <div 
                  className="bg-blue-500 rounded-t w-full transition-all duration-500 hover:bg-blue-600"
                  style={{ height: `${Math.max(rate, 5)}%` }}
                  title={`${day}: ${rate.toFixed(0)}%`}
                  data-testid={`chart-bar-${day.toLowerCase()}`}
                />
                <span className="text-xs text-slate-500 dark:text-slate-400">{day}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Productivity Trends */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="bg-slate-50 dark:bg-slate-900 p-6 rounded-xl"
        >
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">
            Best Productivity Hours
          </h3>
          <div className="space-y-4">
            {bestHours.map(({ time, rate }, index) => (
              <div key={time} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${
                    index === 0 ? 'bg-green-500' : 
                    index === 1 ? 'bg-blue-500' : 'bg-yellow-500'
                  }`} />
                  <span className="text-sm text-slate-700 dark:text-slate-300">{time}</span>
                </div>
                <span className="text-sm font-medium" data-testid={`productivity-rate-${index}`}>
                  {rate}%
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Distraction Analysis */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-slate-50 dark:bg-slate-900 p-6 rounded-xl"
        >
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">
            Distraction Analysis
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-600 dark:text-slate-400">Distraction-free sessions</span>
              <span className="font-semibold text-green-500" data-testid="distraction-free-rate">
                {stats?.distractionFreeRate?.toFixed(0) || 0}%
              </span>
            </div>
            <div className="space-y-2">
              <div className="text-sm text-slate-500 dark:text-slate-400">Top distractions:</div>
              <div className="flex flex-wrap gap-2">
                {topDistractions.map(({ name, count }) => (
                  <Badge 
                    key={name} 
                    variant="secondary" 
                    className="text-xs"
                    data-testid={`distraction-${name.toLowerCase().replace(' ', '-')}`}
                  >
                    {name} ({count})
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Period Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="bg-slate-50 dark:bg-slate-900 p-6 rounded-xl"
        >
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">
            {selectedPeriod === 'week' ? 'Weekly' : selectedPeriod === 'month' ? 'Monthly' : 'Period'} Summary
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-600 dark:text-slate-400">Total sessions</span>
              <span className="font-semibold" data-testid="summary-total-sessions">
                {stats?.totalSessions || 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600 dark:text-slate-400">Total hours</span>
              <span className="font-semibold" data-testid="summary-total-hours">
                {stats?.totalHours?.toFixed(1) || '0.0'}h
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600 dark:text-slate-400">Completion rate</span>
              <span className="font-semibold" data-testid="summary-completion-rate">
                {stats?.completionRate?.toFixed(0) || 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600 dark:text-slate-400">Best day</span>
              <span className="font-semibold text-green-500" data-testid="summary-best-day">
                {stats?.bestDay || 'N/A'}
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
