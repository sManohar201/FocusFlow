import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, MoreHorizontal, Link as LinkIcon } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Task } from "@shared/schema";

type TaskStatus = 'todo' | 'inprogress' | 'done';
type TaskPriority = 'low' | 'medium' | 'high';

interface NewTaskForm {
  title: string;
  description: string;
  priority: TaskPriority;
  estimatedSessions: number;
}

export default function KanbanBoard() {
  const [newTaskForm, setNewTaskForm] = useState<NewTaskForm>({
    title: '',
    description: '',
    priority: 'medium',
    estimatedSessions: 1,
  });
  const [isNewTaskDialogOpen, setIsNewTaskDialogOpen] = useState(false);
  const [draggedTask, setDraggedTask] = useState<Task | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ['/api/tasks'],
  });

  const createTaskMutation = useMutation({
    mutationFn: (task: Omit<Task, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) =>
      apiRequest('POST', '/api/tasks', task),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      setIsNewTaskDialogOpen(false);
      setNewTaskForm({ title: '', description: '', priority: 'medium', estimatedSessions: 1 });
      toast({ title: "Success", description: "Task created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create task", variant: "destructive" });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, ...updates }: { id: string } & Partial<Task>) =>
      apiRequest('PATCH', `/api/tasks/${id}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update task", variant: "destructive" });
    },
  });

  const handleCreateTask = () => {
    if (!newTaskForm.title.trim()) {
      toast({ title: "Error", description: "Task title is required", variant: "destructive" });
      return;
    }
    createTaskMutation.mutate({
      ...newTaskForm,
      status: 'todo',
      completedSessions: 0,
    });
  };

  const handleDragStart = (task: Task) => {
    setDraggedTask(task);
  };

  const handleDragEnd = () => {
    setDraggedTask(null);
  };

  const handleDrop = (status: TaskStatus) => {
    if (draggedTask && draggedTask.status !== status) {
      updateTaskMutation.mutate({
        id: draggedTask.id,
        status,
        ...(status === 'done' && { completedSessions: draggedTask.estimatedSessions }),
      });
    }
    setDraggedTask(null);
  };

  const getTasksByStatus = (status: TaskStatus) => {
    return tasks.filter((task: Task) => task.status === status);
  };

  const getPriorityColor = (priority: TaskPriority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-300';
      case 'medium': return 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-300';
      case 'low': return 'bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-300';
    }
  };

  const getStatusInfo = (status: TaskStatus) => {
    switch (status) {
      case 'todo':
        return { title: 'To Do', color: 'bg-slate-500', count: getTasksByStatus('todo').length };
      case 'inprogress':
        return { title: 'In Progress', color: 'bg-blue-500', count: getTasksByStatus('inprogress').length };
      case 'done':
        return { title: 'Done', color: 'bg-green-500', count: getTasksByStatus('done').length };
    }
  };

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded w-1/3"></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-64 bg-slate-200 dark:bg-slate-700 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
            Task Board
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Organize your tasks and link them to deep work sessions
          </p>
        </div>
        <Dialog open={isNewTaskDialogOpen} onOpenChange={setIsNewTaskDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="bg-blue-500 hover:bg-blue-600 text-white"
              data-testid="button-add-task"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Task
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Task</DialogTitle>
              <DialogDescription>
                Fill out the form below to create a new task for your Kanban board.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Title</label>
                <Input
                  value={newTaskForm.title}
                  onChange={(e) => setNewTaskForm({ ...newTaskForm, title: e.target.value })}
                  placeholder="Enter task title"
                  data-testid="input-task-title"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Description</label>
                <Textarea
                  value={newTaskForm.description}
                  onChange={(e) => setNewTaskForm({ ...newTaskForm, description: e.target.value })}
                  placeholder="Enter task description"
                  data-testid="textarea-task-description"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Priority</label>
                  <Select value={newTaskForm.priority} onValueChange={(value: TaskPriority) => setNewTaskForm({ ...newTaskForm, priority: value })}>
                    <SelectTrigger data-testid="select-task-priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Estimated Sessions</label>
                  <Input
                    type="number"
                    min="1"
                    max="20"
                    value={newTaskForm.estimatedSessions}
                    onChange={(e) => setNewTaskForm({ ...newTaskForm, estimatedSessions: parseInt(e.target.value) || 1 })}
                    data-testid="input-estimated-sessions"
                  />
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsNewTaskDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateTask} disabled={createTaskMutation.isPending} data-testid="button-create-task">
                  {createTaskMutation.isPending ? 'Creating...' : 'Create Task'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {(['todo', 'inprogress', 'done'] as TaskStatus[]).map((status) => {
          const statusInfo = getStatusInfo(status);
          const statusTasks = getTasksByStatus(status);

          return (
            <motion.div
              key={status}
              className="bg-slate-50 dark:bg-slate-900 rounded-xl p-4 min-h-[400px]"
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => handleDrop(status)}
              data-testid={`column-${status}`}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-slate-900 dark:text-white flex items-center space-x-2">
                  <div className={`w-3 h-3 ${statusInfo.color} rounded-full`} />
                  <span>{statusInfo.title}</span>
                  <Badge variant="secondary" className="text-xs">
                    {statusInfo.count}
                  </Badge>
                </h3>
              </div>

              <div className="space-y-3">
                <AnimatePresence>
                  {statusTasks.map((task: Task) => (
                    <motion.div
                      key={task.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card
                        className={`cursor-move hover:shadow-md transition-shadow ${
                          status === 'done' ? 'opacity-75' : ''
                        } ${draggedTask?.id === task.id ? 'opacity-50' : ''}`}
                        draggable
                        onDragStart={() => handleDragStart(task)}
                        onDragEnd={handleDragEnd}
                        data-testid={`task-${task.id}`}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className={`font-medium text-slate-900 dark:text-white text-sm ${
                              status === 'done' ? 'line-through' : ''
                            }`}>
                              {task.title}
                            </h4>
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                              <MoreHorizontal className="w-3 h-3" />
                            </Button>
                          </div>
                          
                          {task.description && (
                            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                              {task.description}
                            </p>
                          )}
                          
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              <Badge className={`text-xs ${getPriorityColor(task.priority!)}`}>
                                {task.priority}
                              </Badge>
                              <span className="text-xs text-slate-400">
                                {task.estimatedSessions} sessions
                              </span>
                            </div>
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-blue-500">
                              <LinkIcon className="w-3 h-3" />
                            </Button>
                          </div>

                          {status === 'inprogress' && (
                            <div className="space-y-1">
                              <Progress 
                                value={(task.completedSessions! / task.estimatedSessions!) * 100} 
                                className="h-1"
                              />
                              <div className="text-xs text-slate-400">
                                {Math.round((task.completedSessions! / task.estimatedSessions!) * 100)}% complete
                              </div>
                            </div>
                          )}

                          {status === 'done' && (
                            <div className="flex items-center justify-between">
                              <Badge className="text-xs bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-300">
                                ✓ Completed
                              </Badge>
                              <span className="text-xs text-slate-400">
                                {task.completedSessions} sessions
                              </span>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
