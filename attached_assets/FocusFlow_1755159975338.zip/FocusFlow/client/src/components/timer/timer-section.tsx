import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import TimerControls from "./timer-controls";
import { useTimer } from "@/hooks/use-timer";
import { formatTime } from "@/lib/date-utils";

export default function TimerSection() {
  const { 
    currentSession, 
    timeRemaining, 
    isRunning, 
    currentSessionIndex, 
    totalSessions, 
    sessionType,
    sessionDuration,
    progress 
  } = useTimer();

  return (
    <Card className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 p-8 mb-8">
      <div className="text-center">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Badge 
            variant="secondary" 
            className="inline-flex items-center space-x-2 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 px-4 py-2 rounded-full text-sm font-medium mb-6"
            data-testid="text-session-info"
          >
            <Clock className="w-4 h-4" />
            <span>
              {currentSession ? 
                `${sessionType} Session ${currentSessionIndex} of ${totalSessions}` : 
                'Ready to Start'
              }
            </span>
          </Badge>
        </motion.div>

        {/* Timer Display */}
        <motion.div 
          className="mb-8"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-6xl sm:text-7xl font-bold text-slate-900 dark:text-white mb-4 font-mono tracking-tight">
            <span data-testid="text-timer-minutes">{formatTime(timeRemaining).minutes}</span>
            <span className="opacity-60">:</span>
            <span data-testid="text-timer-seconds">{formatTime(timeRemaining).seconds}</span>
          </div>
          <div className="text-slate-600 dark:text-slate-400 text-lg" data-testid="text-session-duration">
            <span>{sessionType} Session</span> • <span>{sessionDuration} minutes</span>
          </div>
        </motion.div>

        {/* Progress Ring */}
        <motion.div 
          className="flex justify-center mb-8"
          whileHover={{ scale: 1.05 }}
          transition={{ type: "spring", stiffness: 300 }}
        >
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                className="text-slate-200 dark:text-slate-700"
              />
              <motion.circle 
                cx="50" 
                cy="50" 
                r="45" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="3" 
                strokeLinecap="round" 
                className="text-blue-500 transition-all duration-300"
                style={{
                  strokeDasharray: 283,
                  strokeDashoffset: 283 - (283 * progress / 100)
                }}
                initial={{ strokeDashoffset: 283 }}
                animate={{ strokeDashoffset: 283 - (283 * progress / 100) }}
                transition={{ duration: 0.5 }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span 
                className="text-2xl font-semibold text-slate-900 dark:text-white"
                data-testid="text-progress-percentage"
              >
                {Math.round(progress)}%
              </span>
            </div>
          </div>
        </motion.div>

        {/* Timer Controls */}
        <TimerControls />
      </div>
    </Card>
  );
}
