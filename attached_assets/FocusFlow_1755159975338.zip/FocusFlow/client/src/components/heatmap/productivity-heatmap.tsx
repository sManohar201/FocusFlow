import { useState } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getHeatmapIntensity, generateYearGrid } from "@/lib/heatmap-utils";

export default function ProductivityHeatmap() {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const { data: heatmapData, isLoading } = useQuery({
    queryKey: ['/api/heatmap', selectedYear],
    enabled: true,
  });

  const { data: stats } = useQuery({
    queryKey: ['/api/stats'],
    enabled: true,
  });

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded w-1/3"></div>
        <div className="h-40 bg-slate-200 dark:bg-slate-700 rounded"></div>
      </div>
    );
  }

  const yearGrid = generateYearGrid(selectedYear);
  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 3 }, (_, i) => currentYear - i);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
            Productivity Heatmap
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Track your consistency and identify patterns in your deep work habits
          </p>
        </div>
        <div className="flex items-center space-x-4 mt-4 sm:mt-0">
          <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
            <SelectTrigger className="w-32" data-testid="select-year">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {yearOptions.map(year => (
                <SelectItem key={year} value={year.toString()}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* GitHub-style Heatmap */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-slate-50 dark:bg-slate-900 p-6 rounded-xl"
      >
        <div className="overflow-x-auto">
          <div className="min-w-full space-y-1">
            {/* Month Labels */}
            <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mb-2 pl-8">
              {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(month => (
                <span key={month} className="w-12 text-center">{month}</span>
              ))}
            </div>
            
            {/* Heatmap Grid */}
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, dayIndex) => (
              <div key={day} className="flex items-center space-x-1">
                <div className="text-xs text-slate-500 dark:text-slate-400 w-6 text-right">
                  {dayIndex % 2 === 0 ? day : ''}
                </div>
                <div className="flex space-x-1">
                  {yearGrid.filter((_, weekIndex) => weekIndex % 7 === dayIndex).map((week, weekIndex) => {
                    const sessionCount = heatmapData?.[week.date] || 0;
                    const intensity = getHeatmapIntensity(sessionCount);
                    
                    return (
                      <motion.div
                        key={`${week.date}-${weekIndex}`}
                        className={`w-3 h-3 rounded-sm ${intensity} cursor-pointer`}
                        title={`${week.date}: ${sessionCount} sessions`}
                        whileHover={{ scale: 1.2 }}
                        transition={{ type: "spring", stiffness: 400 }}
                        data-testid={`heatmap-day-${week.date}`}
                      />
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-between mt-6">
          <div className="text-sm text-slate-600 dark:text-slate-400">
            <span data-testid="text-year-total">
              {stats?.totalSessions || 0} sessions
            </span> in {selectedYear}
          </div>
          <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400">
            <span>Less</span>
            <div className="flex space-x-1">
              <div className="w-3 h-3 rounded-sm bg-emerald-100 dark:bg-emerald-900"></div>
              <div className="w-3 h-3 rounded-sm bg-emerald-200 dark:bg-emerald-800"></div>
              <div className="w-3 h-3 rounded-sm bg-emerald-300 dark:bg-emerald-700"></div>
              <div className="w-3 h-3 rounded-sm bg-emerald-400 dark:bg-emerald-600"></div>
              <div className="w-3 h-3 rounded-sm bg-emerald-500 dark:bg-emerald-500"></div>
            </div>
            <span>More</span>
          </div>
        </div>
      </motion.div>

      {/* Summary Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-4"
      >
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 p-4 rounded-lg">
          <div className="text-2xl font-bold text-blue-900 dark:text-blue-100" data-testid="stat-longest-streak">
            {stats?.longestStreak || 0}
          </div>
          <div className="text-sm text-blue-700 dark:text-blue-300">Longest Streak</div>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 p-4 rounded-lg">
          <div className="text-2xl font-bold text-green-900 dark:text-green-100" data-testid="stat-current-streak">
            {stats?.currentStreak || 0}
          </div>
          <div className="text-sm text-green-700 dark:text-green-300">Current Streak</div>
        </div>
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 p-4 rounded-lg">
          <div className="text-2xl font-bold text-purple-900 dark:text-purple-100" data-testid="stat-avg-sessions">
            {stats?.totalSessions ? (stats.totalSessions / 365).toFixed(1) : '0.0'}
          </div>
          <div className="text-sm text-purple-700 dark:text-purple-300">Avg Sessions/Day</div>
        </div>
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 p-4 rounded-lg">
          <div className="text-2xl font-bold text-orange-900 dark:text-orange-100" data-testid="stat-total-hours">
            {Math.round(stats?.totalHours || 0)}
          </div>
          <div className="text-sm text-orange-700 dark:text-orange-300">Total Hours</div>
        </div>
      </motion.div>
    </div>
  );
}
