import { useState } from "react";
import { motion } from "framer-motion";
import Navigation from "@/components/common/navigation";
import TimerSection from "@/components/timer/timer-section";
import ProductivityHeatmap from "@/components/heatmap/productivity-heatmap";
import StatsDigidboard from "@/components/stats/stats-dashboard";
import KanbanBoard from "@/components/tasks/kanban-board";
import SettingsPanel from "@/components/settings/settings-panel";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, BarChart3, CheckSquare, Settings, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTimer } from "@/hooks/use-timer";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("heatmap");
  const { startQuickSession } = useTimer();

  const handleQuickStart = () => {
    startQuickSession();
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Timer Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <TimerSection />
        </motion.div>

        {/* Main Content Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden mt-8"
        >
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="border-b border-slate-200 dark:border-slate-700 px-6">
              <TabsList className="grid w-full grid-cols-4 bg-transparent h-auto p-0">
                <TabsTrigger 
                  value="heatmap" 
                  className="flex items-center space-x-2 py-4 px-1 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 dark:data-[state=active]:text-blue-400 rounded-none bg-transparent"
                  data-testid="tab-heatmap"
                >
                  <Calendar className="w-4 h-4" />
                  <span className="hidden sm:inline">Productivity Heatmap</span>
                  <span className="sm:hidden">Heatmap</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="stats" 
                  className="flex items-center space-x-2 py-4 px-1 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 dark:data-[state=active]:text-blue-400 rounded-none bg-transparent"
                  data-testid="tab-stats"
                >
                  <BarChart3 className="w-4 h-4" />
                  <span className="hidden sm:inline">Detailed Stats</span>
                  <span className="sm:hidden">Stats</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="tasks" 
                  className="flex items-center space-x-2 py-4 px-1 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 dark:data-[state=active]:text-blue-400 rounded-none bg-transparent"
                  data-testid="tab-tasks"
                >
                  <CheckSquare className="w-4 h-4" />
                  <span className="hidden sm:inline">Task Board</span>
                  <span className="sm:hidden">Tasks</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="settings" 
                  className="flex items-center space-x-2 py-4 px-1 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 dark:data-[state=active]:text-blue-400 rounded-none bg-transparent"
                  data-testid="tab-settings"
                >
                  <Settings className="w-4 h-4" />
                  <span className="hidden sm:inline">Settings</span>
                  <span className="sm:hidden">Settings</span>
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="p-6">
              <TabsContent value="heatmap" className="mt-0">
                <ProductivityHeatmap />
              </TabsContent>
              <TabsContent value="stats" className="mt-0">
                <StatsDigidboard />
              </TabsContent>
              <TabsContent value="tasks" className="mt-0">
                <KanbanBoard />
              </TabsContent>
              <TabsContent value="settings" className="mt-0">
                <SettingsPanel />
              </TabsContent>
            </div>
          </Tabs>
        </motion.div>
      </div>

      {/* Floating Quick Start Button */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <Button
          onClick={handleQuickStart}
          size="lg"
          className="w-16 h-16 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 bg-blue-500 hover:bg-blue-600"
          data-testid="button-quick-start"
        >
          <Play className="w-6 h-6" />
        </Button>
      </motion.div>
    </div>
  );
}
