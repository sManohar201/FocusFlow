export function getHeatmapIntensity(sessionCount: number): string {
  if (sessionCount === 0) {
    return 'bg-emerald-100 dark:bg-emerald-900';
  } else if (sessionCount === 1) {
    return 'bg-emerald-200 dark:bg-emerald-800';
  } else if (sessionCount === 2) {
    return 'bg-emerald-300 dark:bg-emerald-700';
  } else if (sessionCount === 3) {
    return 'bg-emerald-400 dark:bg-emerald-600';
  } else {
    return 'bg-emerald-500 dark:bg-emerald-500';
  }
}

export function generateYearGrid(year: number): Array<{ date: string; weekday: number; week: number }> {
  const grid = [];
  const startDate = new Date(year, 0, 1);
  const endDate = new Date(year + 1, 0, 1);
  
  // Find the first Sunday of the year (or the Sunday before if year doesn't start on Sunday)
  const firstSunday = new Date(startDate);
  while (firstSunday.getDay() !== 0) {
    firstSunday.setDate(firstSunday.getDate() - 1);
  }
  
  let currentDate = new Date(firstSunday);
  let weekCount = 0;
  
  while (currentDate < endDate) {
    const dayOfWeek = currentDate.getDay();
    
    // Only include dates that are actually in the target year
    if (currentDate.getFullYear() === year) {
      grid.push({
        date: currentDate.toISOString().split('T')[0],
        weekday: dayOfWeek,
        week: weekCount
      });
    }
    
    currentDate.setDate(currentDate.getDate() + 1);
    
    // Increment week counter on Sundays
    if (dayOfWeek === 0 && currentDate.getFullYear() === year) {
      weekCount++;
    }
  }
  
  return grid;
}

export function getWeekOfYear(date: Date): number {
  const startOfYear = new Date(date.getFullYear(), 0, 1);
  const pastDaysOfYear = (date.getTime() - startOfYear.getTime()) / 86400000;
  return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7);
}

export function getHeatmapTooltip(date: string, sessionCount: number): string {
  const dateObj = new Date(date);
  const formattedDate = dateObj.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
  
  if (sessionCount === 0) {
    return `${formattedDate}: No sessions`;
  } else if (sessionCount === 1) {
    return `${formattedDate}: 1 session`;
  } else {
    return `${formattedDate}: ${sessionCount} sessions`;
  }
}

export function calculateHeatmapStats(heatmapData: Record<string, number>) {
  const values = Object.values(heatmapData);
  const totalSessions = values.reduce((sum, count) => sum + count, 0);
  const activeDays = values.filter(count => count > 0).length;
  const maxSessions = Math.max(...values);
  const avgSessions = totalSessions / values.length;
  
  return {
    totalSessions,
    activeDays,
    maxSessions,
    avgSessions: Math.round(avgSessions * 100) / 100
  };
}

export function getContributionLevel(sessionCount: number, maxSessions: number): 0 | 1 | 2 | 3 | 4 {
  if (sessionCount === 0) return 0;
  if (maxSessions === 0) return 0;
  
  const percentage = sessionCount / maxSessions;
  
  if (percentage <= 0.25) return 1;
  if (percentage <= 0.5) return 2;
  if (percentage <= 0.75) return 3;
  return 4;
}

export function getMonthLabels(): string[] {
  return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
}

export function getDayLabels(): string[] {
  return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
}

export function isCurrentYear(year: number): boolean {
  return year === new Date().getFullYear();
}

export function getCurrentStreak(heatmapData: Record<string, number>): number {
  const today = new Date();
  let streak = 0;
  let currentDate = new Date(today);
  
  while (true) {
    const dateKey = currentDate.toISOString().split('T')[0];
    const sessionCount = heatmapData[dateKey] || 0;
    
    if (sessionCount > 0) {
      streak++;
    } else if (streak > 0) {
      // If we've started counting and hit a day with no sessions, break
      break;
    }
    
    // Go back one day
    currentDate.setDate(currentDate.getDate() - 1);
    
    // Don't go back more than a year
    if (today.getTime() - currentDate.getTime() > 365 * 24 * 60 * 60 * 1000) {
      break;
    }
  }
  
  return streak;
}

export function getLongestStreak(heatmapData: Record<string, number>): number {
  const sortedDates = Object.keys(heatmapData).sort();
  let longestStreak = 0;
  let currentStreak = 0;
  
  for (let i = 0; i < sortedDates.length; i++) {
    const sessionCount = heatmapData[sortedDates[i]];
    
    if (sessionCount > 0) {
      currentStreak++;
      longestStreak = Math.max(longestStreak, currentStreak);
    } else {
      currentStreak = 0;
    }
  }
  
  return longestStreak;
}
